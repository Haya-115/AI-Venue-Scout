export interface LocationResult {
  name: string;
  coordinates: [number, number];
  styleTags: string[];
  indoorOutdoor: "indoor" | "outdoor";
  accessibility: string;
  permit?: {
    required: boolean;
    note: string;
    link?: string;
  };
  description: string;
  photoUrl?: string;
  map?: {
    travelTime: string;
    directionsUrl?: string;
  };
  weather?: {
    summary: string;
    forecast: string;
  };
  sun?: {
    goldenHour: string;
    blueHour: string;
    shadowOrientation: string;
  };
}