import React, { useState } from "react";
import SearchBar from "./components/SearchBar";
import ResultsPane from "./components/ResultsPane";
import LocationDetail from "./components/LocationDetail";
import axios from "axios";
import { LocationResult } from "./types/location";

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL;

function App() {
  const [results, setResults] = useState<LocationResult[]>([]);
  const [selected, setSelected] = useState<LocationResult | null>(null);
  const [favorites, setFavorites] = useState<LocationResult[]>([]);
  const [loading, setLoading] = useState(false);

  const onSearch = async (query: string, filters: any) => {
    setLoading(true);
    try {
      const res = await axios.post(`${API_BASE_URL}/recommend`, { query, filters });
      setResults(res.data.results);
      setSelected(null);
    } finally {
      setLoading(false);
    }
  };

  const onSelect = (loc: LocationResult) => setSelected(loc);

  const onSaveFavorite = async (loc: LocationResult) => {
    await axios.post(`${API_BASE_URL}/favorites`, { location: loc });
    setFavorites([...favorites, loc]);
  };

  return (
    <div className="min-h-screen bg-gray-50 py-10 px-4 font-sans">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-4xl font-extrabold mb-8 text-center">AI Venue Scout Agent</h1>
        <SearchBar onSearch={onSearch} />
        {loading && <div className="mt-8 text-lg">Loading recommendations...</div>}
        {!loading && results.length > 0 && (
          <ResultsPane results={results} onSelect={onSelect} />
        )}
        {selected && (
          <LocationDetail loc={selected} onSave={onSaveFavorite} />
        )}
      </div>
    </div>
  );
}

export default App;