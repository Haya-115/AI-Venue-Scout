import React from "react";
import { LocationResult } from "../types/location";

interface Props {
  loc: LocationResult;
  onSave: (loc: LocationResult) => void;
}

export default function LocationDetail({ loc, onSave }: Props) {
  return (
    <div className="max-w-xl mx-auto p-8 bg-white rounded-2xl shadow-2xl mb-10">
      <h1 className="text-3xl font-bold mb-2">{loc.name}</h1>
      <div className="flex gap-2 mb-4">
        {loc.styleTags.map(tag => (
          <span key={tag} className="bg-gray-200 px-3 py-1 rounded-2xl text-sm">{tag}</span>
        ))}
      </div>
      {loc.photoUrl && (
        <img src={loc.photoUrl} alt={loc.name} className="rounded-xl shadow mb-4" />
      )}
      <div className="mb-2">{loc.description}</div>
      <div><b>Travel Time:</b> {loc.map?.travelTime || "N/A"}</div>
      <div><b>Weather:</b> {loc.weather?.summary || "N/A"}</div>
      <div><b>Best Light:</b> {loc.sun?.goldenHour || "N/A"}</div>
      <div><b>Permit:</b> {loc.permit?.note || "Unknown"}</div>
      <button
        className="mt-4 bg-black text-white px-6 py-2 rounded-2xl"
        onClick={() => onSave(loc)}
      >
        Save to Favorites
      </button>
      <button className="mt-2 bg-gray-700 text-white px-6 py-2 rounded-2xl">
        Export Shoot Plan
      </button>
    </div>
  );
}