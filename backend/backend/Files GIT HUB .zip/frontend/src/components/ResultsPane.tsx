import React from "react";
import { LocationResult } from "../types/location";

interface Props {
  results: LocationResult[];
  onSelect: (location: LocationResult) => void;
}

export default function ResultsPane({ results, onSelect }: Props) {
  return (
    <div className="flex flex-col gap-6 w-full mb-8">
      {results.map(loc => (
        <div
          key={loc.name}
          className="bg-white rounded-2xl shadow-2xl p-6 cursor-pointer"
          onClick={() => onSelect(loc)}
        >
          <div className="text-2xl font-bold">{loc.name}</div>
          <div className="flex gap-2 my-2">
            {loc.styleTags.map(tag => (
              <span key={tag} className="text-xs bg-gray-100 rounded px-2 py-1">
                {tag}
              </span>
            ))}
          </div>
          <div className="text-sm text-gray-600">{loc.description}</div>
          <div className="text-xs mt-2">Permit: {loc.permit?.note || "Unknown"}</div>
        </div>
      ))}
    </div>
  );
}