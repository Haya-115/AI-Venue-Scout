import React, { useState } from "react";

interface Props {
  onSearch: (query: string, filters: any) => void;
}

export default function SearchBar({ onSearch }: Props) {
  const [query, setQuery] = useState("");
  const [filters, setFilters] = useState({
    style: "",
    radius: 10,
    indoorOutdoor: "any",
    season: "",
  });

  return (
    <div className="p-8 rounded-2xl shadow-2xl bg-white flex flex-col gap-4 mb-10">
      <input
        className="text-lg p-4 rounded-2xl border"
        placeholder="Describe your ideal shoot location..."
        value={query}
        onChange={e => setQuery(e.target.value)}
      />
      <div className="flex gap-2">
        <select onChange={e => setFilters({ ...filters, style: e.target.value })}>
          <option value="">Any style</option>
          <option value="romantic">Romantic</option>
          <option value="urban">Urban</option>
          <option value="natural">Natural</option>
          <option value="industrial">Industrial</option>
          <option value="minimal">Minimal</option>
        </select>
        <input
          type="number"
          min="1"
          max="50"
          value={filters.radius}
          onChange={e => setFilters({ ...filters, radius: Number(e.target.value) })}
          className="w-20"
          placeholder="Radius (km)"
        />
        <select onChange={e => setFilters({ ...filters, indoorOutdoor: e.target.value })}>
          <option value="any">Any</option>
          <option value="indoor">Indoor</option>
          <option value="outdoor">Outdoor</option>
        </select>
      </div>
      <button
        className="bg-black text-white px-8 py-2 rounded-2xl text-xl shadow"
        onClick={() => onSearch(query, filters)}
      >
        Search
      </button>
    </div>
  );
}