module.exports = {
  content: ['./src/**/*.{js,jsx,ts,tsx}'],
  theme: {
    extend: {
      borderRadius: {
        '2xl': '1.5rem',
      },
      boxShadow: {
        '2xl': '0 8px 32px 0 rgba(0,0,0,0.08)',
      }
    }
  },
  darkMode: 'class',
  plugins: []
}