import { Request, Response } from "express";
import { getAIRecommendations } from "../services/aiService";
import { getWeather } from "../services/weatherService";
import { getSunTimes } from "../services/astroService";
import { getPermitInfo } from "../services/permitService";
import { getMapData } from "../services/mapService";

export const recommendLocations = async (req: Request, res: Response) => {
  try {
    const { query, filters } = req.body;

    // 1. Get AI recommendations (mocked)
    const locations = await getAIRecommendations(query, filters);

    // 2. Enrich each location with integrations (mocked)
    const enriched = await Promise.all(
      locations.map(async (loc: any) => ({
        ...loc,
        map: await getMapData(loc),
        weather: await getWeather(loc),
        sun: await getSunTimes(loc),
        permit: await getPermitInfo(loc),
      }))
    );

    res.json({ results: enriched });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
};