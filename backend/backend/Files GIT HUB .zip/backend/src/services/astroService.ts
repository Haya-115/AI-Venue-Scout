export async function getSunTimes(loc: any) {
  // MOCK: Returns golden hour time
  return {
    goldenHour: "18:30–19:30",
    blueHour: "19:45–20:05",
    shadowOrientation: "NW"
  };
}