export async function getAIRecommendations(query: string, filters: any) {
  // MOCK: Return static list
  return [
    {
      name: "Rose Garden Florence",
      coordinates: [43.763, 11.255],
      styleTags: ["romantic", "natural"],
      indoorOutdoor: "outdoor",
      accessibility: "easy",
      permit: { required: false, note: "No permit needed" },
      description: "Beautiful garden with roses and sunset views.",
      photoUrl: "/rose-garden.jpg"
    },
    {
      name: "Modern Loft NYC",
      coordinates: [40.730, -73.997],
      styleTags: ["modern", "indoor"],
      indoorOutdoor: "indoor",
      accessibility: "medium",
      permit: { required: true, note: "Contact owner for permit" },
      description: "Loft with industrial vibe, big windows.",
      photoUrl: "/loft.jpg"
    }
  ];
}