export async function getPermitInfo(loc: any) {
  // MOCK: Already included in AI recommendations, but can be extended.
  return loc.permit;
}