export async function getWeather(loc: any) {
  // MOCK: Returns simple weather summary
  return {
    summary: "Clear, 22°C",
    forecast: "Sunny, no rain"
  };
}