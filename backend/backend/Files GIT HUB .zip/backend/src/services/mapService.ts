export async function getMapData(loc: any) {
  // MOCK: Returns travel time and a fake directions URL
  return {
    travelTime: "20 min by car",
    directionsUrl: "https://maps.example.com/directions"
  };
}