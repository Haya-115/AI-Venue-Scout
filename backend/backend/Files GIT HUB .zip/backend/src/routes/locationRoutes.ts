import express from "express";
import { recommendLocations } from "../controllers/locationController";
const router = express.Router();

router.post("/", recommendLocations);

export default router;