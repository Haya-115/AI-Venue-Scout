import express from "express";
const router = express.Router();

router.post("/", (req, res) => {
  // Mock: Return a simple PDF link
  res.json({ url: "https://example.com/shoot-plan.pdf" });
});

export default router;