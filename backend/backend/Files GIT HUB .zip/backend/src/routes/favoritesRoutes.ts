import express from "express";
const router = express.Router();

// Mock: In-memory favorites
let favorites: any[] = [];

router.get("/", (req, res) => res.json({ favorites }));
router.post("/", (req, res) => {
  favorites.push(req.body.location);
  res.json({ success: true });
});

export default router;